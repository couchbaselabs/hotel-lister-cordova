@objc(HotelLister) class HotelLister : CDVPlugin {

}